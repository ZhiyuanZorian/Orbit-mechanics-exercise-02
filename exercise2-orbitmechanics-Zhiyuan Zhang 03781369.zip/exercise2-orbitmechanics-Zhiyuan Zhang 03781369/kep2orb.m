function [r,nu,E,M] = kep2orb(a,e,t,T0,L)
GM=398.6005*10^12;
%The mean motion is computed as follows-
n=sqrt(GM/(a^3));
%Computing Mean Anomaly-
M=wrapTo2Pi(n*(t-T0));
%Iterative solution for E for the next 24 hours-
for i = 1:L
E(i) = M(i);
dE = 1;
while abs(dE) > 10^-6
dE = (M(i) + (e*sin(E(i))) - E(i))/(1 - (e*cos(E(i))));
E(i) = (E(i) + dE);
end
E(i)=wrapTo2Pi(E(i));
r(i) = a*(1 - (e*cos(E(i))));
nu(i) = wrapTo2Pi(2*atan2(sqrt(1+e)*sin(E(i)/2), sqrt(1-e)*cos(E(i)/2)));
end
end


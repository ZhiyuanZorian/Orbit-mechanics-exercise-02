function [ yRK ] = Runge( yprime,t,y0 )
N=length(t);
h=round((t(N)-t(1))/N);
yRK(length(y0),N)=0;
yRK(:,1)=y0;
for i=2:N
    k1=h.*yprime(t(i),yRK(:,i-1));
    k2=h.*yprime((t(i)+(h/2)),(yRK(:,i-1)+(k1*h/2)));
    k3=h.*yprime((t(i)+(h/2)),(yRK(:,i-1)+(k2*h/2)));
    k4=h.*yprime((t(i)+(h)),(yRK(:,i-1)+k3*h));
    yRK(:,i)=yRK(:,i-1)+(k1+(2*k2)+(2*k3)+k4)/6;
end
end
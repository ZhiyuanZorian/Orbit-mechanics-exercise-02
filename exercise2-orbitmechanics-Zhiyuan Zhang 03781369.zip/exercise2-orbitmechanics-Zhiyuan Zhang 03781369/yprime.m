function [ yp ] = yprime( t,y )
GM=398.6005*10^12;
R=sqrt((y(1,1)^2)+(y(2,1)^2)+(y(3,1)^2));
acc=(-(GM/(R^3)).*y(1:3,1));
yp=[y(4,1);y(5,1);y(6,1);acc(1,1);acc(2,1);acc(3,1)];
end


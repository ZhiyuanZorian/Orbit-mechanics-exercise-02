function [ yE ] = Euler(yprime,t,y0)
N=length(t);
h=round((t(N)-t(1))/N);
yE(length(y0),N)=0;
yE(:,1)=y0;
for i=2:N
    yE(:,i)=yE(:,i-1)+(h.*(yprime(t(i-1),yE(:,i-1))));
end
end


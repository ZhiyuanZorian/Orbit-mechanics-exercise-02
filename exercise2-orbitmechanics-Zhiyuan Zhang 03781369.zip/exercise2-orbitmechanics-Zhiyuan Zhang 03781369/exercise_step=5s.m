clear all; close all; clc;
GM=398600500000000;
eps=0.00001;
omegaE=2*pi/86164;
s(1).a=7192000; s(1).e=0.004; s(1).i=98.3*2*pi/360; s(1).o=257.7*2*pi/360;
s(1).w=144.2*2*pi/360;s(1).T0=0;
%% Orbit Calculation
t=5; %t as the input
step=5;
for j=1:1
    s(j).n=sqrt(GM/(s(j).a*s(j).a*s(j).a)); %calculate each n
    s(j).interval=t-s(j).T0;
    s(j).M=s(j).n*s(j).interval*3600; %unit of interval should be s
    s(j).matrix=zeros(7,s(j).interval*3600/step); %value matrix for satellites
    s(j).rmatrix=zeros(3,s(j).interval*3600/step); % rmatrix to describe vector r
    s(j).rdotmatrix=zeros(3,s(j).interval*3600/step); %rdotmatrix to describe vector rdot
    number=s(j).interval*3600/step;
    ecc=s(j).e;
    i0=s(j).i*(-1); o0=s(j).o*(-1); w0=s(j).w*(-1);
    s(j).imatrix=[1,0,0;0,cos(i0),sin(i0);0,(-1)*sin(i0),cos(i0)];   %R1(-i)
    s(j).omatrix=[cos(o0),sin(o0),0;(-1)*sin(o0),cos(o0),0;0,0,1];   %R3(-o)
    s(j).wmatrix=[cos(w0),sin(w0),0;(-1)*sin(w0),cos(w0),0;0,0,1];   %R3(-w) 
    for i=1:number
       s(j).matrix(1,i)=i*step; %unit second
       s(j).matrix(2,i)=s(j).n*s(j).matrix(1,i); % M at each t
       E=s(j).matrix(2,i);   %fisrt value of E at each time.
       M0=E;  
       for k=1:100  %itineration of E at each t
           dE=(M0-E+ecc*sin(E))./(1-ecc*cos(E));
           if(max(abs(dE))<eps)
               break
           end
           E=E+dE;
       end
       s(j).matrix(3,i)=E; %E at each time is calculated.
       s(j).matrix(4,i)=s(j).a*(1-ecc*cos(E)); % r at each time.
       r_temporal=s(j).matrix(4,i);
       s(j).matrix(5,i)=2*atan(tan(E/2)*sqrt((1+ecc)/(1-ecc))); %v at each time
       v_temporal=s(j).matrix(5,i);
       s(j).rmatrix(1,i)=r_temporal*cos(v_temporal);           %vector r line 1
       s(j).rmatrix(2,i)=r_temporal*sin(v_temporal);           %vector r line 2
       s(j).rdotmatrix(1,i)=sin(v_temporal)*(-1);           %vector rdot line 1
       s(j).rdotmatrix(2,i)=cos(v_temporal)+ecc;            %vector rdot line 2
       s(j).matrix(6,i)=r_temporal*cos(v_temporal); %x at eachtime
       s(j).matrix(7,i)=r_temporal*sin(v_temporal); %y at eachtime
    end
    s(j).rdotmatrix = s(j).rdotmatrix*sqrt(GM/(s(j).a*(1-ecc*ecc)));
    s(j).r_equator=s(j).omatrix*s(j).imatrix*s(j).wmatrix*s(j).rmatrix;       %position
    s(j).rdot_equator=s(j).omatrix*s(j).imatrix*s(j).wmatrix*s(j).rdotmatrix; %velocity
    s(j).velocity_magnitude=s(j).rdot_equator.*s(j).rdot_equator;
    s(j).velocity_magnitude(4,:) = sqrt(s(j).velocity_magnitude(1,:).^2 + s(j).velocity_magnitude(2,:).^2 + s(j).velocity_magnitude(3,:).^2);
    s(j).velocity_magnitude(4,:)=sqrt(s(j).velocity_magnitude(4,:));
    s(j).velocity_magnitude(1,:)=sqrt(s(j).rdotmatrix(1,:).^2+s(j).rdotmatrix(2,:).^2);
    s(j).velocity_magnitude(4,:)=s(j).velocity_magnitude(1,:);
end
y_matrix=zeros(6,number);  %set y matrix
y_dotmatrix=zeros(6,number);  %set ydot matrix 
y_matrix(1,1)=s(j).r_equator(1,1);y_matrix(2,1)=s(j).r_equator(2,1);y_matrix(3,1)=s(j).r_equator(3,1); %initial value of y
y_matrix(4,1)=s(j).rdot_equator(1,1);y_matrix(5,1)=s(j).rdot_equator(2,1);y_matrix(6,1)=s(j).rdot_equator(3,1); %initial value of ydot
y_difference23=zeros(6,number);
y_difference45=zeros(6,number);
y_difference113=zeros(6,number);
L=number;
polar(1:L,1:2)=0;
[r,nu,E,M]= kep2orb(s(1).a,s(1).e,s(1).matrix(1,:)',s(1).T0,number);
polar(:,1)=r;
polar(:,2)=nu;
cart(1:3,1:L,1:2)=0;
for i=1:L
[cart(:,i,1),cart(:,i,2)]=kep2cart(s(1).a,s(1).e,polar(i,1),polar(i,2));
end
%Rotating onto the equatorial plane-
R1=@(x)[1,0,0;0,cos(x),sin(x);0,-sin(x),cos(x)];
R3=@(x)[cos(x),sin(x),0;-sin(x),cos(x),0;0,0,1];
%Position and velocity for GOCE in the equatorial plane-
r2=R3(-s(1).o)*R1(-s(1).i)*R3(-s(1).w)*cart(:,:,1);
v2=R3(-s(1).o)*R1(-s(1).i)*R3(-s(1).w)*cart(:,:,2);

%% Task1 Sentinel Orbit 
figure(1)
Earth_coast(3)
h1=plot3(s(1).r_equator(1,:)',s(1).r_equator(2,:)',s(1).r_equator(3,:)');
legend([h1],'Sentinel Satellite')
xlabel('x[m]')
ylabel('y[m]')
zlabel('z[m]')
title('Orbit of Sentinel in Spacefixed Plane')
%% Task 2 and 3
%Solving the differential equation in yprime
y0=[r2(1,1);r2(2,1);r2(3,1);v2(1,1);v2(2,1);v2(3,1)];
t=s(1).matrix(1,:);
% ODE23
options=odeset('InitialStep',5,'MaxStep',5); 			
[t,y]=ode23('yprime',t,y0,options);
diff_r_ode23=r2(:,:)-y(:,1:3)';
diff_v_ode23=v2(:,:)-y(:,4:6)';

figure(2);
subplot(2,1,1);
hold on;
plot(t,diff_r_ode23(1,:));
hold on;
plot(t,diff_r_ode23(2,:));
hold on;
plot(t,diff_r_ode23(3,:));
title('Position with ODE23 for steps of 5s');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(m)');
grid on;
hold off;

subplot(2,1,2);
hold on;
plot(t,diff_v_ode23(1,:));
hold on;
plot(t,diff_v_ode23(2,:));
hold on;
plot(t,diff_v_ode23(3,:));
title('Velocity with ODE23 for steps of 5s');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(m/s)');
grid on;
hold off;

% ODE45
options=odeset('InitialStep',5,'MaxStep',5); 			
[t,y]=ode45('yprime',t,y0,options);

diff_r_ode45=r2(:,:)-y(:,1:3)';
diff_v_ode45=v2(:,:)-y(:,4:6)';

figure(3);
subplot(2,1,1);
hold on;
plot(t,diff_r_ode45(1,:));
hold on;
plot(t,diff_r_ode45(2,:));
hold on;
plot(t,diff_r_ode45(3,:));
title('Position with ODE45 for steps of 5s');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(m)');
grid on;
hold off;

subplot(2,1,2);
hold on;
plot(t,diff_v_ode45(1,:));
hold on;
plot(t,diff_v_ode45(2,:));
hold on;
plot(t,diff_v_ode45(3,:));
title('Velocity with ODE45 for steps of 5s');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(m/s)');
grid on;
hold off;

% ODE113 
options=odeset('InitialStep',5,'MaxStep',50); 			
[t,y]=ode113('yprime',t,y0,options);

diff_r_ode113=r2(:,:)-y(:,1:3)';
diff_v_ode113=v2(:,:)-y(:,4:6)';

figure(4);
subplot(2,1,1);
hold on;
plot(t,diff_r_ode113(1,:));
hold on;
plot(t,diff_r_ode113(2,:));
hold on;
plot(t,diff_r_ode113(3,:));
title('Position with ODE113 for steps of 5s');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(m)');
grid on;
hold off;

subplot(2,1,2);
hold on;
plot(t,diff_v_ode113(1,:));
hold on;
plot(t,diff_v_ode113(2,:));
hold on;
plot(t,diff_v_ode113(3,:));
title('Velocity with ODE113 for steps of 5s');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(m/s)');
grid on;
hold off;

%% Task 4
%Perturbed Orbit due to Earth's Oblateness 
%Solving the differential equation in yprime2
% ODE23
options=odeset('InitialStep',5,'MaxStep',5); 			
[t,y]=ode23('yprime2',t,y0,options);

diff_r_y2_ode23=r2(:,:)-y(:,1:3)';
diff_v_y2_ode23=v2(:,:)-y(:,4:6)';

figure(5);
subplot(2,1,1);
hold on;
plot(t,diff_r_y2_ode23(1,:)./1000);
hold on;
plot(t,diff_r_y2_ode23(2,:)./1000);
hold on;
plot(t,diff_r_y2_ode23(3,:)./1000);
title('Position with ODE23 for steps of 5s (disturbed)');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(km)');
grid on;
hold off;

subplot(2,1,2);
hold on;
plot(t,diff_v_y2_ode23(1,:)./1000);
hold on;
plot(t,diff_v_y2_ode23(2,:)./1000);
hold on;
plot(t,diff_v_y2_ode23(3,:)./1000);
title('Velocity with ODE23 for steps of 5s (disturbed)');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(km/s)');
grid on;
hold off;

% ODE45
options=odeset('InitialStep',5,'MaxStep',5); 			
[t,y]=ode45('yprime2',t,y0,options);

diff_r_y2_ode45=r2(:,:)-y(:,1:3)';
diff_v_y2_ode45=v2(:,:)-y(:,4:6)';

figure(6);
subplot(2,1,1);
hold on;
plot(t,diff_r_y2_ode45(1,:)./1000);
hold on;
plot(t,diff_r_y2_ode45(2,:)./1000);
hold on;
plot(t,diff_r_y2_ode45(3,:)./1000);
title('Position with ODE45 for steps of 5s (disturbed)');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(km)');
grid on;
hold off;

subplot(2,1,2);
hold on;
plot(t,diff_v_y2_ode45(1,:)./1000);
hold on;
plot(t,diff_v_y2_ode45(2,:)./1000);
hold on;
plot(t,diff_v_y2_ode45(3,:)./1000);
title('Velocity with ODE45 for steps of 5s (disturbed)');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(km/s)');
grid on;
hold off;

% ODE113
options=odeset('InitialStep',5,'MaxStep',50); 			
[t,y]=ode113('yprime2',t,y0,options);

diff_r_y2_ode113=r2(:,:)-y(:,1:3)';
diff_v_y2_ode113=v2(:,:)-y(:,4:6)';

figure(7);
subplot(2,1,1);
hold on;
plot(t,diff_r_y2_ode113(1,:)./1000);
hold on;
plot(t,diff_r_y2_ode113(2,:)./1000);
hold on;
plot(t,diff_r_y2_ode113(3,:)./1000);
title('Position with ODE113 for steps of 5s (disturbed)');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(km/s)');
grid on;
hold off;

subplot(2,1,2);
hold on;
plot(t,diff_v_y2_ode113(1,:)./1000);
hold on;
plot(t,diff_v_y2_ode113(2,:)./1000);
hold on;
plot(t,diff_v_y2_ode113(3,:)./1000);
title('Velocity with ODE113 for steps of 5s (disturbed)');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(km/s)');
grid on;
hold off;

%Decomposition into RSW components-
% ODE23
options=odeset('InitialStep',5,'MaxStep',5); 			
[t,y]=ode23('yprime2',t,y0,options);
diff_r_y2=-r2(:,:)+y(:,1:3)'; %difference between undisurbed and disturbed for position 
diff_v_y2=-v2(:,:)+y(:,4:6)'; %difference between undisurbed and disturbed for velocity
diff_r_RSW(1:3,1:L)=0;
diff_v_RSW(1:3,1:L)=0;
r0(1:3,1:L)=0;v0(1:3,1:L)=0;r0xv0(1:3,1:L)=0;
eR(1:3,1:L)=0;eS(1:3,1:L)=0;eW(1:3,1:L)=0;
for i=1:L
r0(1:3,i)=[r2(1,i);r2(2,i);r2(3,i)]; 
v0(1:3,i)=[v2(1,i);v2(2,i);v2(3,i)]; 
r0xv0(1:3,i)=cross(r0(:,i),v0(:,i));
%Unit Vector in the direction R-
eR(1:3,i)=r0(:,i)/norm(r0(:,i));
%Unit Vector in the direction W-
eW(1:3,i)=r0xv0(:,i)/norm(r0xv0(:,i));
%Unit Vector in the direction S-
eS(1:3,i)=cross(eW(:,i),eR(:,i));

% Difference in position vector in RSW system
diff_r_RSW(1,i)=sum(diff_r_y2(:,i).*eR(:,i));
diff_r_RSW(2,i)=sum(diff_r_y2(:,i).*eS(:,i));
diff_r_RSW(3,i)=sum(diff_r_y2(:,i).*eW(:,i));
% Difference in velocity vector in RSW system
diff_v_RSW(1,i)=sum(diff_v_y2(:,i).*eR(:,i));
diff_v_RSW(2,i)=sum(diff_v_y2(:,i).*eS(:,i));
diff_v_RSW(3,i)=sum(diff_v_y2(:,i).*eW(:,i));
end

figure(8);
subplot(2,1,1);
hold on;
plot(t,diff_r_RSW(1,:)./1000);
hold on;
plot(t,diff_r_RSW(2,:)./1000);
hold on;
plot(t,diff_r_RSW(3,:)./1000);
title('Position with ODE23 for steps of 5s');
legend('R','S','W');
xlabel('time(s)');
ylabel('Diffenernce(km)');
grid on;
hold off;

subplot(2,1,2);
hold on;
plot(t,diff_v_RSW(1,:)./1000);
hold on;
plot(t,diff_v_RSW(2,:)./1000);
hold on;
plot(t,diff_v_RSW(3,:)./1000);
title('Velocity with ODE23 for steps of 5s');
legend('R','S','W');
xlabel('time(s)');
ylabel('Diffenernce(km/s)');
grid on;
hold off;

% ODE45
options=odeset('InitialStep',5,'MaxStep',5); 			
[t,y]=ode45('yprime2',t,y0,options);
diff_r_y2=-r2(:,:)+y(:,1:3)'; %difference between undisurbed and disturbed for position 
diff_v_y2=-v2(:,:)+y(:,4:6)'; %difference between undisurbed and disturbed for velocity

diff_r_RSW(1:3,1:L)=0;
diff_v_RSW(1:3,1:L)=0;
r0(1:3,1:L)=0;
v0(1:3,1:L)=0;
r0xv0(1:3,1:L)=0;
eR(1:3,1:L)=0;
eS(1:3,1:L)=0;
eW(1:3,1:L)=0;
for i=1:L
r0(1:3,i)=[r2(1,i);r2(2,i);r2(3,i)]; 
v0(1:3,i)=[v2(1,i);v2(2,i);v2(3,i)]; 
r0xv0(1:3,i)=cross(r0(:,i),v0(:,i));
%Unit Vector in the direction R-
eR(1:3,i)=r0(:,i)/norm(r0(:,i));
%Unit Vector in the direction W-
eW(1:3,i)=r0xv0(:,i)/norm(r0xv0(:,i));
%Unit Vector in the direction S-
eS(1:3,i)=cross(eW(:,i),eR(:,i));

% Difference in position vector in RSW system
diff_r_RSW(1,i)=sum(diff_r_y2(:,i).*eR(:,i));
diff_r_RSW(2,i)=sum(diff_r_y2(:,i).*eS(:,i));
diff_r_RSW(3,i)=sum(diff_r_y2(:,i).*eW(:,i));
% Difference in velocity vector in RSW system
diff_v_RSW(1,i)=sum(diff_v_y2(:,i).*eR(:,i));
diff_v_RSW(2,i)=sum(diff_v_y2(:,i).*eS(:,i));
diff_v_RSW(3,i)=sum(diff_v_y2(:,i).*eW(:,i));
end
 
figure(9);
subplot(2,1,1);
hold on;
plot(t,diff_r_RSW(1,:)./1000);
hold on;
plot(t,diff_r_RSW(2,:)./1000);
hold on;
plot(t,diff_r_RSW(3,:)./1000);
title('Position with ODE45 for steps of 5s');
legend('R','S','W');
xlabel('time(s)');
ylabel('Diffenernce(km)');
grid on;
hold off;

subplot(2,1,2);
hold on;
plot(t,diff_v_RSW(1,:)./1000);
hold on;
plot(t,diff_v_RSW(2,:)./1000);
hold on;
plot(t,diff_v_RSW(3,:)./1000);
title('Velocity with ODE45 for steps of 5s');
legend('R','S','W');
xlabel('time(s)');
ylabel('Diffenernce(km/s)');
grid on;
hold off;

% ODE113
options=odeset('InitialStep',5,'MaxStep',5); 			
[t,y]=ode113('yprime2',t,y0,options);

diff_r_y2=-r2(:,:)+y(:,1:3)'; %difference between undisurbed and disturbed for position 
diff_v_y2=-v2(:,:)+y(:,4:6)'; %difference between undisurbed and disturbed for velocity
diff_r_RSW(1:3,1:L)=0;
diff_v_RSW(1:3,1:L)=0;
r0(1:3,1:L)=0;
v0(1:3,1:L)=0;
r0xv0(1:3,1:L)=0;
eR(1:3,1:L)=0;
eS(1:3,1:L)=0;
eW(1:3,1:L)=0;
for i=1:L
r0(1:3,i)=[r2(1,i);r2(2,i);r2(3,i)]; 
v0(1:3,i)=[v2(1,i);v2(2,i);v2(3,i)]; 
r0xv0(1:3,i)=cross(r0(:,i),v0(:,i));
%Unit Vector in the direction R-
eR(1:3,i)=r0(:,i)/norm(r0(:,i));
%Unit Vector in the direction W-
eW(1:3,i)=r0xv0(:,i)/norm(r0xv0(:,i));
%Unit Vector in the direction S-
eS(1:3,i)=cross(eW(:,i),eR(:,i));
% Difference in position vector in RSW system
diff_r_RSW(1,i)=sum(diff_r_y2(:,i).*eR(:,i));
diff_r_RSW(2,i)=sum(diff_r_y2(:,i).*eS(:,i));
diff_r_RSW(3,i)=sum(diff_r_y2(:,i).*eW(:,i));
% Difference in velocity vector in RSW system
diff_v_RSW(1,i)=sum(diff_v_y2(:,i).*eR(:,i));
diff_v_RSW(2,i)=sum(diff_v_y2(:,i).*eS(:,i));
diff_v_RSW(3,i)=sum(diff_v_y2(:,i).*eW(:,i));
end

figure(10);
subplot(2,1,1);
hold on;
plot(t,diff_r_RSW(1,:)./1000);
hold on;
plot(t,diff_r_RSW(2,:)./1000);
hold on;
plot(t,diff_r_RSW(3,:)./1000);
title('Position with ODE113 for steps of 5s');
legend('R','S','W');
xlabel('time(s)');
ylabel('Diffenernce(km)');
grid on;
hold off;

subplot(2,1,2);
hold on;
plot(t,diff_v_RSW(1,:)./1000);
hold on;
plot(t,diff_v_RSW(2,:)./1000);
hold on;
plot(t,diff_v_RSW(3,:)./1000);
title('Velocity with ODE113 for steps of 5s');
legend('R','S','W');
xlabel('time(s)');
ylabel('Diffenernce(km/s)');
grid on;
hold off;

%% Task 6
%Euler Method
%Solving the differential equation in yprime
y0=[r2(1,1);r2(2,1);r2(3,1);v2(1,1);v2(2,1);v2(3,1)];
[yE]=Euler(@yprime,t,y0);

diff_r_E=r2(:,:)-yE(1:3,:);
diff_v_E=v2(:,:)-yE(4:6,:);

figure(11);
subplot(2,1,1);
hold on;
plot(t,diff_r_E(1,:)./1000);
hold on;
plot(t,diff_r_E(2,:)./1000);
hold on;
plot(t,diff_r_E(3,:)./1000);
title('Position with Euler method for steps of 5s');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(km)');
grid on;
hold off;

subplot(2,1,2);
hold on;
plot(t,diff_v_E(1,:)./1000);
hold on;
plot(t,diff_v_E(2,:)./1000);
hold on;
plot(t,diff_v_E(3,:)./1000);
title('Velocity with Euler method for steps of 5s');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(km/s)');
grid on;
hold off;

%Runge-Kutta 4th Order Method
%Solving the differential equation in yprime
y0=[r2(1,1);r2(2,1);r2(3,1);v2(1,1);v2(2,1);v2(3,1)];
[yRK]=RungeKutta(@yprime,t,y0);

diff_r_RK=r2(:,:)-yRK(1:3,:);
diff_v_RK=v2(:,:)-yRK(4:6,:);

figure(12);
subplot(2,1,1);
hold on;
plot(t,diff_r_RK(1,:)./1000);
hold on;
plot(t,diff_r_RK(2,:)./1000);
hold on;
plot(t,diff_r_RK(3,:)./1000);
title('Position with Runge-Kutta method for steps of 5s');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(km)');
grid on;
hold off;

subplot(2,1,2);
hold on;
plot(t,diff_v_RK(1,:)./1000);
hold on;
plot(t,diff_v_RK(2,:)./1000);
hold on;
plot(t,diff_v_RK(3,:)./1000);
title('Velocity with Runge-Kutta method for steps of 5s');
legend('x','y','z');
xlabel('time(s)');
ylabel('Diffenernce(km/s)');
grid on;
hold off;


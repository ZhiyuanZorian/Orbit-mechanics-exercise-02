%% Prepared data
clear all; close all; clc;
GM=398600500000000;
eps=0.00001;
omegaE=2*pi/86164;
s(1).a=7192000; s(1).e=0.004; s(1).i=98.3*2*pi/360; s(1).o=257.7*2*pi/360;
s(1).w=144.2*2*pi/360;s(1).T0=0;
%% Orbit Calculation
t=5; %t as the input
step=15;
for j=1:1
    s(j).n=sqrt(GM/(s(j).a*s(j).a*s(j).a)); %calculate each n
    s(j).interval=t-s(j).T0;
    s(j).M=s(j).n*s(j).interval*3600; %unit of interval should be s
    s(j).matrix=zeros(7,s(j).interval*3600/step); %value matrix for satellites
    s(j).rmatrix=zeros(3,s(j).interval*3600/step); % rmatrix to describe vector r
    s(j).rdotmatrix=zeros(3,s(j).interval*3600/step); %rdotmatrix to describe vector rdot
    number=s(j).interval*3600/step;
    ecc=s(j).e;
    i0=s(j).i*(-1); o0=s(j).o*(-1); w0=s(j).w*(-1);
    s(j).imatrix=[1,0,0;0,cos(i0),sin(i0);0,(-1)*sin(i0),cos(i0)];   %R1(-i)
    s(j).omatrix=[cos(o0),sin(o0),0;(-1)*sin(o0),cos(o0),0;0,0,1];   %R3(-o)
    s(j).wmatrix=[cos(w0),sin(w0),0;(-1)*sin(w0),cos(w0),0;0,0,1];   %R3(-w) 
    for i=1:number
       s(j).matrix(1,i)=i*step; %unit second
       s(j).matrix(2,i)=s(j).n*s(j).matrix(1,i); % M at each t
       E=s(j).matrix(2,i);   %fisrt value of E at each time.
       M0=E;  
       for k=1:100  %itineration of E at each t
           dE=(M0-E+ecc*sin(E))./(1-ecc*cos(E));
           if(max(abs(dE))<eps)
               break
           end
           E=E+dE;
       end
       s(j).matrix(3,i)=E; %E at each time is calculated.
       s(j).matrix(4,i)=s(j).a*(1-ecc*cos(E)); % r at each time.
       r_temporal=s(j).matrix(4,i);
       s(j).matrix(5,i)=2*atan(tan(E/2)*sqrt((1+ecc)/(1-ecc))); %v at each time
       v_temporal=s(j).matrix(5,i);
       s(j).rmatrix(1,i)=r_temporal*cos(v_temporal);           %vector r line 1
       s(j).rmatrix(2,i)=r_temporal*sin(v_temporal);           %vector r line 2
       s(j).rdotmatrix(1,i)=sin(v_temporal)*(-1);           %vector rdot line 1
       s(j).rdotmatrix(2,i)=cos(v_temporal)+ecc;            %vector rdot line 2
       s(j).matrix(6,i)=r_temporal*cos(v_temporal); %x at eachtime
       s(j).matrix(7,i)=r_temporal*sin(v_temporal); %y at eachtime
    end
    s(j).rdotmatrix = s(j).rdotmatrix*sqrt(GM/(s(j).a*(1-ecc*ecc)));
    s(j).r_equator=s(j).omatrix*s(j).imatrix*s(j).wmatrix*s(j).rmatrix;       %position
    s(j).rdot_equator=s(j).omatrix*s(j).imatrix*s(j).wmatrix*s(j).rdotmatrix; %velocity
    s(j).velocity_magnitude=s(j).rdot_equator.*s(j).rdot_equator;
    %s(j).velocity_magnitude(4,:)=s(j).velocity_magnitude(1,:)+s(j).velocity_magnitude(2,:)+s(j).velocity_magnitude(3,:);
    %s(j).velocity_magnitude(4,:)=sqrt(s(j).velocity_magnitude(4,:));
    s(j).velocity_magnitude(4,:) = sqrt(s(j).velocity_magnitude(1,:).^2 + s(j).velocity_magnitude(2,:).^2 + s(j).velocity_magnitude(3,:).^2);
    %sum=sqrt(sum);
    s(j).velocity_magnitude(4,:)=sqrt(s(j).velocity_magnitude(4,:));
    s(j).velocity_magnitude(1,:)=sqrt(s(j).rdotmatrix(1,:).^2+s(j).rdotmatrix(2,:).^2);
    s(j).velocity_magnitude(4,:)=s(j).velocity_magnitude(1,:);
    x=s(j).r_equator(1,:)';
    y=s(j).r_equator(2,:)';
    z=s(j).r_equator(3,:)';
end
y_matrix=zeros(6,number);  %set y matrix
y_dotmatrix=zeros(6,number);  %set ydot matrix 
y_matrix(1,1)=s(j).r_equator(1,1);y_matrix(2,1)=s(j).r_equator(2,1);y_matrix(3,1)=s(j).r_equator(3,1); %initial value of y
y_matrix(4,1)=s(j).rdot_equator(1,1);y_matrix(5,1)=s(j).rdot_equator(2,1);y_matrix(6,1)=s(j).rdot_equator(3,1); %initial value of ydot
y_difference23=zeros(6,number);
y_difference45=zeros(6,number);
y_difference113=zeros(6,number);

%% ODE 
times = linspace(step,s(j).interval*3600,number);
options = odeset('InitialStep', 5, 'MaxStep', 5);
x0 = s(1).r_equator(1,1);
y0 = s(1).r_equator(2,1);
z0 = s(1).r_equator(3,1);
vx0 = s(j).rdot_equator(1,1);
vy0 = s(j).rdot_equator(2,1);
vz0 = s(j).rdot_equator(3,1);
y0 = [x0, y0, z0, vx0, vy0, vz0];
% 添加 r_matrix 为额外参数
[t_ode23, y_ode23] = ode23(@(t, y) yprime(t, y), times, y0, options);
[t_ode45, y_ode45] = ode45(@(t, y) yprime(t, y), times, y0, options);
[t_ode113, y_ode113] = ode113(@(t, y) yprime(t, y), times, y0, options);
y_difference23(1:3,:)=(y_ode23(:,1:3)'- s(1).r_equator);
y_difference23(4:6,:)=(y_ode23(:,4:6)'- s(1).rdot_equator);
y_difference45(1:3,:)=(y_ode45(:,1:3)'- s(1).r_equator);
y_difference45(4:6,:)=(y_ode45(:,4:6)'- s(1).rdot_equator);
y_difference113(1:3,:)=(y_ode113(:,1:3)'- s(1).r_equator);
y_difference113(4:6,:)=(y_ode113(:,4:6)'- s(1).rdot_equator);

for i=1:number
    if mod(i,3035/step)==0
        y_difference23(:,i)=(y_difference23(:,i-1)+y_difference23(:,i+1))/2;
        y_difference45(:,i)=(y_difference45(:,i-1)+y_difference45(:,i+1))/2;
        y_difference113(:,i)=(y_difference113(:,i-1)+y_difference113(:,i+1))/2;
    else
        i=i;
    end
end

        
%% ode23
figure(1)
Earth_coast(3)
h1=plot3(s(1).r_equator(1,:)',s(1).r_equator(2,:)',s(1).r_equator(3,:)');
legend([h1],'Sentinel Satellite')
xlabel('x[m]')
ylabel('y[m]')
zlabel('z[m]')
title('Orbit of Sentinel in Spacefixed Plane')
figure(2)
hold on;
h1=plot(s(1).matrix(1,:), y_difference23(1,:));
hold on;
h2=plot(s(1).matrix(1,:), y_difference23(2,:));
hold on;
h3=plot(s(1).matrix(1,:), y_difference23(3,:));
hold on;
legend([h1,h2,h3],'X','Y','Z')
xlim([0 number*step+2000])
%xlim([3020 3050])
xlabel('Time [s]')
ylabel('Position [m]')
title('Position difference (ODE23)')
figure(3)
hold on;
h1=plot(s(1).matrix(1,:), y_difference23(4,:));
hold on;
h2=plot(s(1).matrix(1,:), y_difference23(5,:));
hold on;
h3=plot(s(1).matrix(1,:), y_difference23(6,:));
hold on;
legend([h1,h2,h3],'X','Y','Z')
xlim([0 number*step+2000])
%xlim([3020 3050])
xlabel('Time [s]')
ylabel('Velocity [m/s]')
title('Velocity differen (ODE23)')
%% ODE 45
figure(4)
hold on;
h1=plot(s(1).matrix(1,:), y_difference45(1,:));
hold on;
h2=plot(s(1).matrix(1,:), y_difference45(2,:));
hold on;
h3=plot(s(1).matrix(1,:), y_difference45(3,:));
hold on;
legend([h1,h2,h3],'X','Y','Z')
xlim([0 number*step+2000])
%xlim([3020 3050])
xlabel('Time [s]')
ylabel('Position [m]')
title('Position difference (ODE45)')
figure(5)
hold on;
h1=plot(s(1).matrix(1,:), y_difference45(4,:));
hold on;
h2=plot(s(1).matrix(1,:), y_difference45(5,:));
hold on;
h3=plot(s(1).matrix(1,:), y_difference45(6,:));
hold on;
legend([h1,h2,h3],'X','Y','Z')
xlim([0 number*step+2000])
%xlim([3020 3050])
xlabel('Time [s]')
ylabel('Velocity [m/s]')
title('Velocity difference (ODE45)')


